# Codveda Technologies Internship – Final Submission

Name: Mahek Sarkhedi  
Role: Data Analysis Intern  
Company: Codveda Technologies  

## Overview
This repository contains all the tasks completed during my internship at
Codveda Technologies. The work is organized level-wise and demonstrates
my learning and practical implementation of Python, data analysis,
and machine learning concepts.

## Internship Levels Covered
- **Level 1 – Basic**
  - Python fundamentals
  - Data cleaning and preprocessing
  - Data visualization (bar plot, line chart, scatter plot)

- **Level 2 – Intermediate**
  - Data analysis using multiple datasets
  - All tasks implemented in a single Python file
  - Datasets include Iris, Stock Prices, and House Price Prediction

- **Level 3 – Advanced**
  - Machine learning and analytical tasks
  - All tasks implemented in a single Python file
  - Use cases include Sentiment Analysis and Customer Churn Prediction

## Project Structure

Codveda_Internship/
│
├── Level_1_Basic/
│ ├── level1_task1.py
│ ├── level1_task2.py
│ ├── level1_task3.py
│ └── cleaned_data_level1.csv
│
├── Level_2_Intermediate/
│ └── level2_all_tasks.py
│
├── Level_3_Advanced/
│ └── level3_tasks.py
│
└── README.md


## Technologies Used
- Python
- Pandas
- NumPy
- Matplotlib
- Scikit-learn

## How to Run the Code
1. Install Python (version 3.x)
2. Open terminal or command prompt
3. Navigate to the project directory
4. Run the required file:
   ```bash
   python level2_all_tasks.py or all tasks Complete.


Important Note

Due to GitHub file size limitations, large datasets and virtual environment
files have not been uploaded to this repository. All datasets were used
locally during development and can be shared if required.

Status

All assigned tasks for Level 1, Level 2, and Level 3 have been successfully
completed and submitted as part of the internship requirements.

Acknowledgement

I would like to thank Codveda Technologies for providing this internship
opportunity and a structured learning environment.
   


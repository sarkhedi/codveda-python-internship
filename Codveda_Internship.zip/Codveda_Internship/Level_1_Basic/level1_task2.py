import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# ===============================
# Load Cleaned Dataset
# ===============================
df = pd.read_csv("cleaned_data_level1.csv")
print("✅ Dataset Loaded Successfully")

# ===============================
# Summary Statistics
# ===============================
print("\n📊 Summary Statistics:")
print(df.describe())

# ===============================
# Select ONLY Numeric Columns
# ===============================
num_df = df.select_dtypes(include=["number"])

# If numeric columns not detected properly
if num_df.shape[1] == 0:
    temp = df.copy()
    for col in temp.columns:
        temp[col] = pd.to_numeric(temp[col], errors="coerce")
    num_df = temp.select_dtypes(include=["number"])

# Remove empty columns
num_df = num_df.dropna(axis=1, how="all")

print("\n✅ Numeric Columns Used:")
print(num_df.columns)

# ===============================
# Histogram
# ===============================
num_df.hist(figsize=(10, 8))
plt.suptitle("Histogram of Numeric Data")
plt.tight_layout()
plt.show()

# ===============================
# Boxplot (Safe Version)
# ===============================
plt.figure(figsize=(10, 5))
num_df.iloc[:, :6].plot(kind="box")   # limit columns to avoid crash
plt.title("Boxplot (Numeric Columns Only)")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# ===============================
# Correlation Heatmap
# ===============================
plt.figure(figsize=(8, 6))
sns.heatmap(num_df.corr(), annot=True, cmap="coolwarm")
plt.title("Correlation Heatmap")
plt.tight_layout()
plt.show()

print("✅ TASK 2 COMPLETED SUCCESSFULLY")

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

# ===============================
# 1. Load Dataset
# ===============================
file_name = "cleaned_data_level1.csv"

if os.path.exists(file_name):
    df = pd.read_csv(file_name)
    print(f"✅ Dataset '{file_name}' Loaded Successfully")
else:
    print(f"⚠️ '{file_name}' not found. Generating sample data...")
    # Creating sample data just in case
    data = {
        'Month': ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct'],
        'Sales': [1500, 1800, 2200, 2100, 2500, 2700, 3000, 2900, 3100, 3300],
        'Ad_Spend': [200, 250, 300, 280, 350, 380, 400, 390, 420, 450],
        'Category': ['Electronics', 'Clothing', 'Electronics', 'Clothing', 'Home',
                     'Electronics', 'Home', 'Clothing', 'Home', 'Electronics']
    }
    df = pd.DataFrame(data)

# Set visual style
sns.set_theme(style="whitegrid")

# ===============================
# 2. Bar Plot (Categorical Data)
# ===============================
plt.figure(figsize=(10, 6))

# FIXED LINE: Explicitly included 'str' to silence the warning
cat_cols = df.select_dtypes(include=['object', 'category', 'str']).columns

if len(cat_cols) > 0:
    # Use 'Category' if it exists, otherwise pick the first categorical column
    cat_col = 'Category' if 'Category' in df.columns else cat_cols[0]

    # Plotting
    sns.countplot(data=df, x=cat_col, hue=cat_col, palette='viridis', legend=False)

    plt.title(f'Bar Plot: Frequency of {cat_col}', fontsize=15, fontweight='bold')
    plt.xlabel(cat_col, fontsize=12)
    plt.ylabel('Count', fontsize=12)

    plt.tight_layout()
    plt.savefig('task3_bar_plot.png')
    print("✅ Saved: task3_bar_plot.png")
    plt.show()
else:
    print("⚠️ No categorical columns found for Bar Plot.")

# ===============================
# 3. Line Chart (Trends)
# ===============================
plt.figure(figsize=(10, 6))

# Logic to choose X and Y axes
if 'Month' in df.columns and 'Sales' in df.columns:
    x_data = df['Month']
    y_data = df['Sales']
    x_label = 'Month'
    y_label = 'Sales'
else:
    # Fallback: Use Index as X, and first Numeric Column as Y
    x_data = df.index
    num_cols = df.select_dtypes(include=['number']).columns

    if len(num_cols) > 0:
        y_label = num_cols[0]
        y_data = df[y_label]
        x_label = "Index"

        # Optimization: Limit points if dataset is massive to prevent messy graph
        if len(df) > 100:
            print(f"ℹ️ Dataset is large ({len(df)} rows). Plotting first 100 rows for clarity.")
            x_data = x_data[:100]
            y_data = y_data[:100]
    else:
        print("⚠️ No numeric columns found for Line Chart.")
        x_data, y_data = [], []

if len(x_data) > 0:
    plt.plot(x_data, y_data, marker='o', linestyle='-', color='b', linewidth=2)
    plt.title(f'Line Chart: {y_label} Trend', fontsize=15, fontweight='bold')
    plt.xlabel(str(x_label), fontsize=12)
    plt.ylabel(str(y_label), fontsize=12)
    plt.grid(True)
    plt.tight_layout()
    plt.savefig('task3_line_chart.png')
    print("✅ Saved: task3_line_chart.png")
    plt.show()

# ===============================
# 4. Scatter Plot (Relationships)
# ===============================
plt.figure(figsize=(10, 6))

num_cols = df.select_dtypes(include=['number']).columns

if len(num_cols) >= 2:
    x_scatter = num_cols[0]
    y_scatter = num_cols[1]

    # Optimization: Sample 1000 points if the dataset is too large
    plot_df = df if len(df) < 1000 else df.sample(1000)

    sns.scatterplot(data=plot_df, x=x_scatter, y=y_scatter, s=100, color='red', alpha=0.6)

    plt.title(f'Scatter Plot: {x_scatter} vs {y_scatter}', fontsize=15, fontweight='bold')
    plt.xlabel(x_scatter, fontsize=12)
    plt.ylabel(y_scatter, fontsize=12)

    plt.tight_layout()
    plt.savefig('task3_scatter_plot.png')
    print("✅ Saved: task3_scatter_plot.png")
    plt.show()
else:
    print("⚠️ Not enough numeric columns for a scatter plot.")

print("\n✅ TASK 3 COMPLETED SUCCESSFULLY")
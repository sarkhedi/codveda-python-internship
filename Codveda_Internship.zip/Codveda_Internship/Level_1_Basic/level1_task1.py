import pandas as pd
import os

# 1. Load the dataset
file_path = 'data/2) Stock Prices Data Set.csv'

if not os.path.exists(file_path):
    print(f"CRITICAL ERROR: File '{file_path}' not found in {os.getcwd()}")
else:
    df = pd.read_csv(file_path)
    print("--- TASK 1: DATA CLEANING START ---")
    print(f"Rows loaded: {len(df)}")

    # 2. Handle missing values [cite: 34]
    df.fillna(df.mean(numeric_only=True), inplace=True)
    df.dropna(inplace=True)
    print("✅ Missing values handled.")

    # 3. Remove duplicates [cite: 35]
    before = len(df)
    df.drop_duplicates(inplace=True)
    print(f"✅ Removed {before - len(df)} duplicate rows.")

    # 4. Standardize formats [cite: 35]
    if 'date' in df.columns:
        df['date'] = pd.to_datetime(df['date'])
        print("✅ Date format standardized.")

    # Save and Force Output
    df.to_csv('cleaned_data_level1.csv', index=False)
    print("--- TASK 1 COMPLETE: 'cleaned_data_level1.csv' created ---")
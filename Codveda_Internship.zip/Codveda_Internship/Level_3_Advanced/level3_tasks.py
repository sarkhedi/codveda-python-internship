import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from textblob import TextBlob
import os

# Set visual style
sns.set_theme(style="darkgrid")

# =================================================================
# TASK 1: PREDICTIVE MODELING (CLASSIFICATION)
# Dataset: churn-bigml-80.csv & churn-bigml-20.csv
# Objective: Predict if a customer will churn (leave the service)
# =================================================================
print("\n--- [LEVEL 3: TASK 1] Predictive Modeling (Churn Classification) ---")

train_path = 'churn-bigml-80.csv'
test_path = 'churn-bigml-20.csv'

if os.path.exists(train_path) and os.path.exists(test_path):
    train_df = pd.read_csv(train_path)
    test_df = pd.read_csv(test_path)

    # Preprocessing: Encode categorical text to numbers
    le = LabelEncoder()
    for df in [train_df, test_df]:
        df['International plan'] = le.fit_transform(df['International plan'])
        df['Voice mail plan'] = le.fit_transform(df['Voice mail plan'])
        df['Churn'] = le.fit_transform(df['Churn'])

    # Feature selection: Drop non-numeric 'State' and target 'Churn'
    X_train = train_df.drop(['Churn', 'State'], axis=1)
    y_train = train_df['Churn']
    X_test = test_df.drop(['Churn', 'State'], axis=1)
    y_test = test_df['Churn']

    # Scaling features for better model performance
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    # Train Random Forest Classifier
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train_scaled, y_train)

    # Evaluate
    predictions = model.predict(X_test_scaled)
    print(f"Model Accuracy: {accuracy_score(y_test, predictions):.4f}")
    print("\nClassification Report:\n", classification_report(y_test, predictions))

    # Visualize Confusion Matrix
    plt.figure(figsize=(6, 4))
    sns.heatmap(confusion_matrix(y_test, predictions), annot=True, fmt='d', cmap='Greens')
    plt.title('Task 1: Confusion Matrix (Churn Prediction)')
    plt.xlabel('Predicted')
    plt.ylabel('Actual')
    plt.show()
else:
    print("Churn datasets not found.")

# =================================================================
# TASK 3: NLP - SENTIMENT ANALYSIS
# Dataset: 3) Sentiment dataset.csv
# Objective: Classify text sentiment as Positive, Neutral, or Negative
# =================================================================
print("\n--- [LEVEL 3: TASK 3] NLP Sentiment Analysis ---")
sentiment_file = '3) Sentiment dataset.csv'

if os.path.exists(sentiment_file):
    df_nlp = pd.read_csv(sentiment_file)


    # NLP Analysis using TextBlob
    def analyze_sentiment(text):
        if pd.isna(text): return 'Neutral'
        analysis = TextBlob(str(text))
        if analysis.sentiment.polarity > 0:
            return 'Positive'
        elif analysis.sentiment.polarity == 0:
            return 'Neutral'
        else:
            return 'Negative'


    df_nlp['Sentiment_Type'] = df_nlp['Text'].apply(analyze_sentiment)

    # Display results
    print("Sample NLP Results:")
    print(df_nlp[['Text', 'Sentiment_Type']].head())

    # Visualization
    plt.figure(figsize=(8, 5))
    sns.countplot(x='Sentiment_Type', data=df_nlp, palette='viridis')
    plt.title('Task 3: Sentiment Distribution (NLP Analysis)')
    plt.show()
else:
    print(f"File {sentiment_file} not found.")

print("\n--- Level 3 All Tasks Completed ---")
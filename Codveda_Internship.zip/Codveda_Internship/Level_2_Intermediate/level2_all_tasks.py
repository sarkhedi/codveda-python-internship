import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from statsmodels.tsa.seasonal import seasonal_decompose
import os

# Set professional visualization style
sns.set_theme(style="whitegrid")

# =================================================================
# TASK 1: REGRESSION ANALYSIS
# Dataset: 4) house Prediction Data Set.csv
# Objective: Predict house price (MEDV) based on number of rooms (RM)
# =================================================================
print("\n--- [LEVEL 2: TASK 1] Regression Analysis (Housing Data) ---")
house_file = '4) house Prediction Data Set.csv'

if os.path.exists(house_file):
    # Load whitespace-separated data (Boston Housing format)
    df_house = pd.read_csv(house_file, sep='\s+', header=None)
    df_house.columns = ['CRIM', 'ZN', 'INDUS', 'CHAS', 'NOX', 'RM', 'AGE', 'DIS', 'RAD', 'TAX', 'PTRATIO', 'B', 'LSTAT',
                        'MEDV']

    # Feature: Rooms (RM), Target: Price (MEDV)
    X = df_house[['RM']]
    y = df_house['MEDV']

    # Split: 80% Training, 20% Testing
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Initialize and Train Model
    reg_model = LinearRegression()
    reg_model.fit(X_train, y_train)

    # Prediction and Evaluation
    y_pred = reg_model.predict(X_test)
    print(f"R-squared (Accuracy): {r2_score(y_test, y_pred):.4f}")
    print(f"Mean Squared Error: {mean_squared_error(y_test, y_pred):.4f}")

    # Plotting
    plt.figure(figsize=(8, 5))
    plt.scatter(X_test, y_test, alpha=0.6, color='royalblue', label='Actual Price')
    plt.plot(X_test, y_pred, color='crimson', linewidth=2, label='Regression Line')
    plt.title('House Price Prediction: Rooms (RM) vs Price (MEDV)')
    plt.xlabel('Average Number of Rooms')
    plt.ylabel('Price (in $1000s)')
    plt.legend()
    plt.show()
else:
    print(f"File {house_file} not found.")

# =================================================================
# TASK 2: TIME SERIES ANALYSIS
# Dataset: 2) Stock Prices Data Set.csv
# Objective: Detect trends and seasonality in Apple (AAPL) stock
# =================================================================
print("\n--- [LEVEL 2: TASK 2] Time Series Analysis (Stock Data) ---")
stock_file = '2) Stock Prices Data Set.csv'

if os.path.exists(stock_file):
    df_stock = pd.read_csv(stock_file)
    df_stock['date'] = pd.to_datetime(df_stock['date'])

    # Filter for AAPL and prepare index
    aapl_df = df_stock[df_stock['symbol'] == 'AAPL'].copy()
    aapl_df.set_index('date', inplace=True)
    aapl_df = aapl_df['close'].resample('D').mean().ffill()

    # Calculate 30-Day Moving Average for smoothing
    moving_avg = aapl_df.rolling(window=30).mean()

    # Visualization: Price and Moving Average
    plt.figure(figsize=(12, 6))
    plt.plot(aapl_df, label='Daily Close Price', alpha=0.4, color='gray')
    plt.plot(moving_avg, label='30-Day Moving Average', color='darkorange', linewidth=2)
    plt.title('AAPL Stock Price: Trend & Moving Average Smoothing')
    plt.legend()
    plt.show()

    # Time Series Decomposition (Trend, Seasonality, Residuals)
    print("Decomposing time series into components...")
    result = seasonal_decompose(aapl_df, model='additive', period=365)
    result.plot()
    plt.show()
else:
    print(f"File {stock_file} not found.")

# =================================================================
# TASK 3: CLUSTERING ANALYSIS (K-MEANS)
# Dataset: 1) iris.csv
# Objective: Group iris flowers based on feature similarities
# =================================================================
print("\n--- [LEVEL 2: TASK 3] Clustering Analysis (Iris Data) ---")
iris_file = '1) iris.csv'

if os.path.exists(iris_file):
    df_iris = pd.read_csv(iris_file)
    X_iris = df_iris.drop('species', axis=1)  # Drop label for unsupervised learning

    # Step 1: Standardize features
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X_iris)

    # Step 2: Elbow Method to find the optimal number of clusters (K)
    wcss = []
    for k in range(1, 11):
        kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
        kmeans.fit(X_scaled)
        wcss.append(kmeans.inertia_)

    plt.figure(figsize=(8, 4))
    plt.plot(range(1, 11), wcss, marker='o', color='forestgreen', linestyle='--')
    plt.title('Elbow Method: Finding Optimal K Clusters')
    plt.xlabel('Number of Clusters (k)')
    plt.ylabel('WCSS (Error)')
    plt.show()

    # Step 3: Apply K-Means with K=3 (based on elbow and domain knowledge)
    final_kmeans = KMeans(n_clusters=3, random_state=42, n_init=10)
    clusters = final_kmeans.fit_predict(X_scaled)

    # Visualizing Clusters
    plt.figure(figsize=(8, 6))
    plt.scatter(X_scaled[:, 0], X_scaled[:, 1], c=clusters, cmap='viridis', s=50, alpha=0.8)
    plt.title('K-Means Clustering of Iris Dataset (K=3)')
    plt.xlabel('Sepal Length (Scaled)')
    plt.ylabel('Sepal Width (Scaled)')
    plt.show()
else:
    print(f"File {iris_file} not found.")

print("\n--- Level 2 Script Execution Finished ---")